self.__precacheManifest = [
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "05dd9ca1c1ad2b3aca35",
    "url": "/static/js/main.c73c9040.chunk.js"
  },
  {
    "revision": "13d3c6929b0b8ef28191",
    "url": "/static/js/2.b187e13d.chunk.js"
  },
  {
    "revision": "05dd9ca1c1ad2b3aca35",
    "url": "/static/css/main.d868c58e.chunk.css"
  },
  {
    "revision": "e3f8fcdeda2f9bbc3f2eca9731f38b16",
    "url": "/index.html"
  }
];