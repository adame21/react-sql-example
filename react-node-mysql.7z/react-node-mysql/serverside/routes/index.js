var express = require("express");
var router = express.Router();

//added this here to get the db.pool.query functionality
var db = require("../db/db");

/* GET home page. */
router.get("/", function(req, res, next) {
  //just a default thing - will get you your main page when you do npm run build and put what is in build folder inside public folder
  res.render("index", { title: "Express" });
});

//create endpoint that brings back all movies in database "moviesdb" under category "movies"
router.get("/getmovies", async (req, res) => {
  //gets movies from the moviesdb database
  var movies = await db.pool.query(`SELECT * FROM moviesdb.movies`);
  //gets the categories so  you can sort out the movies with category names
  var categories = await db.pool.query(`SELECT * FROM moviesdb.categories`);
  //starts running on the movies array
  var sortedMovies = movies.map(movie => {
    //find everytime the category id matches the movie's category id and adds it under .categoryname (which includes both id and name) inside each array object "movie"
    movie.categoryname = categories.find(category => {
      return movie.categoryid == category.id;
    });
    //brings back each modified movie that now has the category inside it under .categoryname into the new array
    return movie;
  });
  res.json(sortedMovies);
});


//add movie endpoint
router.post('/addmovie', async(req,res)=>{
  //defines the query according to the post body to add the movie
  let query = `INSERT INTO moviesdb.movies (name,poster,categoryid) VALUES ('${req.body.name}', '${req.body.poster}', ${req.body.category})`
  //actually adds the movie, gets back a result that doesent matter
  let result = await db.pool.query(query);
  res.json(result);
})

//delete movie endpoint
router.post('/deletemovie', async(req,res)=>{
  console.log(req.body)
  //we use req.body.id because we sent it as an object with {id:"actualyid"}
  let result = await db.pool.query(`DELETE FROM moviesdb.movies WHERE id=${req.body.id} `);
  res.json(result)
})

//search movie endpoint
router.get('/find/:name', async(req,res)=>{
  //dynamic sql query to retrieve movie by name
  let result = await db.pool.query(`SELECT * FROM moviesdb.movies WHERE name='${req.params.name}'`)
  res.json(result);
})


//gets all the categories to create a dropdown or radio buttons on the client
router.get("/getcategories", async (req, res) => {
  //sql query to get all categories
  var categories = await db.pool.query(`SELECT * FROM moviesdb.categories`);
  res.json(categories);
});

/*Initialization stuff: remove the slash kohavit to enable


//create db:
router.get('/createdb', async(req,res)=>{
  //creates a database with the name moviesdb
  await db.pool.query('CREATE DATABASE moviesdb');

  //a response just to end this endpoint - what is in the response is not important
  res.json({ok:"ok"});
})

//create a movies table:
router.get('/createmovies', async(req,res)=>{
  //creates a table called movies in "moviesdb" database with a id, name, poster, categoryid fields, with id being primary key
  await db.pool.query(`CREATE TABLE moviesdb.movies (
    id int NOT NULL AUTO_INCREMENT,
    name varchar(255) NOT NULL,
    poster varchar(255) NOT NULL,
    categoryid int NOT NULL,
    PRIMARY KEY (id)
  )`);
  //a response just to end this endpoint - what is in the response is not important
  res.json({ok:"ok"});
})


//creates a category table
router.get('/createcategories', async(req,res)=>{
  //creates a table called categories in "moviesdb" database with a id, name with id being primary key
  await db.pool.query(`CREATE TABLE moviesdb.categories (
    id int NOT NULL AUTO_INCREMENT,
    name varchar(255) NOT NULL,
    PRIMARY KEY (id)
  )`);
    //a response just to end this endpoint - what is in the response is not important
    res.json({ok:"ok"});
})


//add categories
router.get('/addcategories', async(req,res)=>{
  //each line adds a different category, the id will be put in automatically - DONT FORGET - needs to have 'gershaim' since its a string
  await db.pool.query(`INSERT INTO moviesdb.categories (name) VALUES ('Comedy')`);
  await db.pool.query(`INSERT INTO moviesdb.categories (name) VALUES ('Action')`);
  await db.pool.query(`INSERT INTO moviesdb.categories (name) VALUES ('Horror')`);
  await db.pool.query(`INSERT INTO moviesdb.categories (name) VALUES ('Drama')`);


  //a response just to end this endpoint - what is in the response is not important
  res.json({ok:"ok"})
})

*/

module.exports = router;
