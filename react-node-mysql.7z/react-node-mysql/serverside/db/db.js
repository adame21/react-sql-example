//folder for database connection with promise mysql
//will be used by importing with "var db = require('./db/db');"
//this requires the db.connect function to be used after importing

//import promise mysql (requires "npm i --save promise-mysql")
var mysql = require("promise-mysql");

//create database connection and configure it

var db = {
  pool: null,
  connect: function() {
    var pool = mysql.createPool({
      host: "localhost",
      user: "root",
      password: "root",
      //database: 'moviesdb',
      // this line should not be added if database does not exist,
      // only use it after creation of the db OR dont use it at all and specify database to use like moviesdb.tablename
      connectionLimit: 10
    });
    this.pool = pool;
    console.log("Connected to db ");
  }
};

//exports the variable we used "db" to create the connection
module.exports = db;
