var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');


//these have been added:

//imports the database and connection (requires "npm i --save promise-mysql")
var db = require('./db/db');
//allows cross-origin - used BEFORE npm run build while developing (requires "npm i --save cors")
var cors = require('cors');


var indexRouter = require('./routes/index');


var app = express();


//these have been added:

//connect to the database
db.connect();
//allows cross origin
app.use(cors());


app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);


module.exports = app;
