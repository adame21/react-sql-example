import React, { Component } from 'react';
import './App.css';
import ShowMovies from './components/ShowMovies';
import AddMovie from './components/AddMovie';
import SearchMovie from './components/SearchMovie';

class App extends Component {

  state={
    allCategories:[], //placeholder to avoid errors
    allMovies:[] // same as above
  }

  async componentDidMount(){
    //gets all categories, its here because that's only needed once unlike movies which we will update
    let res = await fetch('http://localhost:3000/getcategories')
    let categories = await res.json();
    //so now we have it from the database and we will put into react state
    this.setState({allCategories:categories})

    this.refresh();
  }


  //this function is sent wherever we want to be able to re-render
  async refresh(){
    //gets all the movies from the database, used multiple times in this app, movies are already sorted to have categoryname
    let res = await fetch('http://localhost:3000/getmovies')
    let movies = await res.json();
    //puts movies into react state
    this.setState({allMovies:movies});

  }


  render() {
    //will contain sorted categories arrays with each having its correct movies
    var sortedMovies = [];
    //this checks if we already have the information to avoid waste
    if(this.state.allMovies.length !==0 && this.state.allCategories.length !==0){
      //runs on category array 
      for(let i =0; i< this.state.allCategories.length; i++){
        //match by id to add an array of every correct movie
        var tempArr = this.state.allMovies.filter(movie=> movie.categoryid == this.state.allCategories[i].id)
        //push the array of movies of the current category in the loop into the daddy array
        sortedMovies.push(tempArr);
        
      }
    }



    return (
      <div className="App">
      <SearchMovie />
      <AddMovie refresh={this.refresh.bind(this)} categories={this.state.allCategories} />
      {sortedMovies.map((movie,i)=><ShowMovies key={i} refresh={this.refresh.bind(this)}  allmovies2={movie} />)}
      </div>
    );
  }
}

export default App;
