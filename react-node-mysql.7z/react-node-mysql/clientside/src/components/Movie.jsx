import React, { Component } from 'react';


class Movie extends Component {
    state = {  }
    render() { 
        return ( 
            <div className="movie">
                <h3>{this.props.movie.name}</h3>
                <img className="poster" src={this.props.movie.poster} alt={this.props.movie.name} />
                <h4>{this.props.movie.categoryname.name}</h4>
                <button onClick={this.deleteMovie.bind(this)}>X</button>
            </div>
         );
    }
    //does a post to the server where you will use req.body.id to get back what you sent
   async deleteMovie(){
    fetch('http://localhost:3000/deletemovie',{
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({id:this.props.movie.id})
      })
      .then(r=>r.json())
      .then(data=>{
          alert("deleted")
          //cause re-render upon adding
          this.props.refresh();
      })
    }
}
 
export default Movie;