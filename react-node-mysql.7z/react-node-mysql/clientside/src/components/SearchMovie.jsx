import React, { Component } from 'react';
import ResultMovie from './ResultMovie';


class SearchMovie extends Component {
    state = { 
        foundMovie:[] //placeholder to avoid errors
     }
    render() { 
        return ( 
            <div className="block">
            <h2>Search by title:</h2>
            <input
              type="text"
              name="name"
              placeholder="Movie title..."
              onChange={this.handleChange.bind(this)}
            />
            <br/>
            <button onClick={this.fetchMovie.bind(this)}>Get movie</button>

            {this.state.foundMovie.map((movie,i)=> <ResultMovie key={i} movie={movie}  />)}
            
          </div>
         );
    }
    handleChange(ev){
        this.setState({[ev.target.name]:ev.target.value});
    }

  async  fetchMovie(){
      //sends the request in the right syntax for params
     let res =await   fetch('http://localhost:3000/find/'+ this.state.name);
     let result = await res.json();
     console.log(result)
     //puts the movie thats in array form into state so now it will map it and actually show
     this.setState({foundMovie:result});
    }
}
 
export default SearchMovie;