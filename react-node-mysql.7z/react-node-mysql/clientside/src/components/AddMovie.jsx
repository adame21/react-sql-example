import React, { Component } from "react";

class AddMovie extends Component {
  state = {
      name:"",
      poster:"",
      category:"1" // this is 1 because default is 1st category
  };
  render() {
    return (
      <div>
        <h1>Add Movie:</h1>
        <label>Movie name:</label>
        <br />
        <input
          type="text"
          name="name"
          onChange={this.handleChange.bind(this)}
        />
        <br />
        <label>Movie poster:</label>
        <br />
        <input
          type="text"
          name="poster"
          onChange={this.handleChange.bind(this)}
        />
        <br />
        <label>Movie category:</label>
        <br />
        <select
          type="text"
          name="category"
          onChange={this.handleChange.bind(this)}
        >
          {this.props.categories.map(category => (
            <option key={category.id} value={category.id}>
              {category.name}
            </option>
          ))}
        </select>

        {/* {this.props.categories.map(category => (
          <label key={category.id}>
            <input
              onChange={this.handleChange.bind(this)}
              type="radio"
              name="category"
              value={category.id}
            />
            {category.name}
          </label>
        ))} */}


        <br/>
        <button onClick={this.addMovie.bind(this)}>Add movie!</button>
      </div>
    );
  }

  handleChange(ev) {
    this.setState({ [ev.target.name]: ev.target.value });
  }
  //does a post to the server and send the state which has ONLY what we need so its ready
  addMovie(){
    fetch('http://localhost:3000/addmovie', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(this.state)
      })
      .then(r=>r.json())
      .then(data=>{
          console.log(data)
          alert("Movie added!")
          //refresh the render
          this.props.refresh();
      })
  }
}

export default AddMovie;
