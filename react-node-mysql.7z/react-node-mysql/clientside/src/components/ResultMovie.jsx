import React, { Component } from "react";

class ResultMovie extends Component {
  state = {};
  //this component exists for showing the search result
  render() {
    return (
      <div className="movie block">
        <h3>{this.props.movie.name}</h3>
        <img
          className="poster"
          src={this.props.movie.poster}
          alt=""
        />
      </div>
    );
  }
}

export default ResultMovie;
