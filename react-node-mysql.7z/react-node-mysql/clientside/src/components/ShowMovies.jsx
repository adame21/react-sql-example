import React, { Component } from 'react';
import Movie from './Movie';

class ShowMovies extends Component {
    //this component is basically the daddy category of each array of movies
    state = {  }
    render() { 
        return ( 
            <div>
                <h1>{this.props.allmovies2[0].categoryname.name}</h1>
                
                {this.props.allmovies2.map(movie=> <Movie key={movie.id} movie={movie} refresh={this.props.refresh.bind(this)} />)}
            </div>
         );
    }
}
 
export default ShowMovies;